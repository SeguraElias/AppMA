package net.elias.usodeaudio;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class activity_english extends AppCompatActivity {

    MediaPlayer reproductor;

    ImageButton cero, one, two, three, four, five, six, seven, eight, nine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english);

        cero = findViewById(R.id.btnCero);
        one = findViewById(R.id.btnOne);
        two = findViewById(R.id.btnTwo);
        three = findViewById(R.id.btnThree);
        four = findViewById(R.id.btnFour);
        five = findViewById(R.id.btnFive);
        six = findViewById(R.id.btnSix);
        seven = findViewById(R.id.btnSeven);
        eight = findViewById(R.id.btnEight);
        nine = findViewById(R.id.btnNine);

        cero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_english.this, R.raw.cero);
                reproductor.start();
            }
        });

        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_english.this, R.raw.one);
                reproductor.start();
            }
        });

        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_english.this, R.raw.two);
                reproductor.start();
            }
        });

        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_english.this, R.raw.three);
                reproductor.start();
            }
        });

        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_english.this, R.raw.four);
                reproductor.start();
            }
        });

        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_english.this, R.raw.five);
                reproductor.start();
            }
        });

        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_english.this, R.raw.six);
                reproductor.start();
            }
        });

        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_english.this, R.raw.seven);
                reproductor.start();
            }
        });

        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_english.this, R.raw.eight);
                reproductor.start();
            }
        });

        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_english.this, R.raw.nine);
                reproductor.start();
            }
        });
    }
}