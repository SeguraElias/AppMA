package net.elias.usodeaudio;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class activity_spanish extends AppCompatActivity {

    MediaPlayer reproductor;
    ImageButton zero, uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spanish);

        zero = findViewById(R.id.btnZero);
        uno = findViewById(R.id.btnUno);
        dos = findViewById(R.id.btnDos);
        tres = findViewById(R.id.btnTres);
        cuatro = findViewById(R.id.btnCuatro);
        cinco = findViewById(R.id.btnCinco);
        seis = findViewById(R.id.btnSeis);
        siete = findViewById(R.id.btnSiete);
        ocho = findViewById(R.id.btnOcho);
        nueve = findViewById(R.id.btnNueve);

        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_spanish.this, R.raw.zero);
                reproductor.start();
            }
        });

        uno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_spanish.this, R.raw.uno);
                reproductor.start();
            }
        });

        dos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_spanish.this, R.raw.dos);
                reproductor.start();
            }
        });

        tres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_spanish.this, R.raw.tres);
                reproductor.start();
            }
        });

        cuatro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_spanish.this, R.raw.cuatro);
                reproductor.start();
            }
        });

        cinco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_spanish.this, R.raw.cinco);
                reproductor.start();
            }
        });

        seis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_spanish.this, R.raw.seis);
                reproductor.start();
            }
        });

        siete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_spanish.this, R.raw.siete);
                reproductor.start();
            }
        });

        ocho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_spanish.this, R.raw.ocho);
                reproductor.start();
            }
        });

        nueve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reproductor!=null){
                    reproductor.release();
                    reproductor = null;
                }
                reproductor = MediaPlayer.create(activity_spanish.this, R.raw.nueve);
                reproductor.start();
            }
        });

    }
}